#!/bin/bash
set -e
mkdir -p build
cd build
cmake ..
make
echo "Build complete. Run ./sample to execute the program."
