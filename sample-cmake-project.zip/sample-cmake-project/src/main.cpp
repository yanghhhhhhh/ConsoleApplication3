#include <iostream>
int main() {
    std::cout << "Hello from CMake + Mise on macOS!" << std::endl;
    return 0;
}
