#include <gtest/gtest.h>
TEST(FirstGroup, Test1) {
    EXPECT_TRUE(true);
}
TEST(FirstGroup, Test2) {
    EXPECT_TRUE(true);
}
TEST(SecondGroup, Test1) {
    EXPECT_TRUE(true);
}
TEST(SecondGroup, Test2) {
    EXPECT_TRUE(true);
}