#include <iostream>

int main() {
    std::cout << "Hello, Linux GCC cross-compilation world!" << std::endl;
    return 0;
}
